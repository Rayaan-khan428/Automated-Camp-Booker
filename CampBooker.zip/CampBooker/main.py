import time  # Add time delays
from selenium import webdriver  # Web scraping module

driver = webdriver.Chrome(executable_path=r'C:\Users\Rayaa_8vku9qo\Documents\chromedriver.exe')


def fillInfo(month, day):
    # fillInfo: Enter the following information: Language, Park, Arrival Month, Nights staying, Equipment, Party Size
    driver.get(
        'https://reservation.pc.gc.ca/Home.aspx?_ga=2.162053243.631429708.1625680631-1155729991.1611932576&gccf=true')

    # Select Language #
    if day == Days[0]:
        # this code will only be executed if it is the first date
        selectLanguage = driver.find_element_by_css_selector('#btnEnglish')
        selectLanguage.click()

    # Select Park #
    selectParkdrp = driver.find_element_by_id('ddlLocations')  # id of the dropdown box (location)
    time.sleep(0.5)
    for option in selectParkdrp.find_elements_by_tag_name('option'):
        if option.text == "Bruce Peninsula":
            option.click()
            break

    # Arrival Date #
    selectMonth = driver.find_element_by_id('ddlArrivalMonth')  # id of the dropdown box (month)
    time.sleep(0.5)  # time delay fixes glitch where month isn't selected
    for option in selectMonth.find_elements_by_tag_name('option'):
        if option.text == month:
            option.click()
            break

    selectDay = driver.find_element_by_id('ddlArrivalDay')  # id of the dropdown box (day)
    for option in selectDay.find_elements_by_tag_name('option'):
        if option.text == str(day):
            option.click()
            break
    print(f'\narrival: {month}, {day}')

    # Nights staying #
    selectNights = driver.find_element_by_id('ddlNights')  # id of the dropdown box (nights staying)
    for option in selectNights.find_elements_by_tag_name('option'):
        if option.text == "1":
            option.click()
            break

    # Equipment #
    selectEquipment = driver.find_element_by_id('ddlEquipmentSub')  # id of the dropdown box (equipment)
    for option in selectEquipment.find_elements_by_tag_name('option'):
        if option.text == "Van/Pick-up":
            option.click()
            break

    # Party Size #
    selectPSize = driver.find_element_by_id('ddlPartySize')  # id of the dropdown box (party size)
    for option in selectPSize.find_elements_by_tag_name('option'):
        if option.text == "5":
            option.click()
            break

    # Find Sites #
    findSites = driver.find_element_by_id('MainContentPlaceHolder_imageButtonList')
    findSites.click()

    # Click General Campground Area #
    clickCyprus = driver.find_element_by_xpath('//a[@href="' + 'BrucePeninsula%2fCyprusLake%3fList' + '"]')
    clickCyprus.click()
    # function ending


def checkAvailability():
    global availability  # can be accessed anywhere
    name = []  # hold all of the campgrounds name
    status = []  # hold status of all campgrounds
    move = 0  # for printing the right right name and status to the console
    unavailable_grounds = []  # keep count of the unavailable campgrounds
    available_grounds = []  # keep count of the available campgrounds

    table = driver.find_element_by_css_selector('.list_new')  # 1. Locates table with campgrounds
    table_body = table.find_elements_by_tag_name('tbody')[1]  # 2. Locates 2nd table body (1st table body is invisible)
    time.sleep(1)  # wait one second
    options = table_body.find_elements_by_tag_name('tr')  # 3. Stores number of campgrounds in variable options
    print(f'Found {len(options)} campgrounds')  # 4. print how many campgrounds are found

    for option in options:  # 5. for every cG (campgrounds) print name then status (unavailable/available)
        name.append(str.splitlines(option.text)[0])  # add cG (campground) name to list
        status.append(option.find_element_by_tag_name('img').get_attribute('alt'))  # add status of cG to list
        print(f'Campsite: {name[move]}: {status[move]}')
        if status[move] == 'Unavailable' or status[move] == 'Restrictions':  # Track # of grounds that are unavailable
            unavailable_grounds.append(name[move])
        elif status[move] == 'Available':  # stores the name of available campgrounds
            available_grounds.append(name[move])
        move += 1

    if len(unavailable_grounds) == 3:
        availability = False
    elif len(unavailable_grounds) < 3:
        print('This campground is available!')
        # if there are less than 3 campgrounds in the list that means there are some that are available
        available(available_grounds)
        availability = True

    return availability  # not sure why I am returning here
    # function ending


def available(available_campgrounds):

    # navigate to campground page and see which sites are available
    table = driver.find_element_by_css_selector('.list_new')  # 1. Locates table with campgrounds
    table_body = table.find_elements_by_tag_name('tbody')[1]  # 2. Locates 2nd table body (1st table body is invisible)
    time.sleep(1)  # wait one second
    options = table_body.find_elements_by_tag_name('tr')  # 3. Stores number of campgrounds in variable options

    for option in options:
        if available_campgrounds[options] == str.splitlines(option.text)[0]:
            option.click()

    pass


Months = ['Jul', 'Aug']  # The two months we want to share in
Days = [12, 16, 17, 23, 24, 30, 31, 6, 7, 13, 14, 20, 21, 27, 28]

availability = False  # availability is initially false
i = 0  # move counter for months
j = -1  # move counter for days # starts at -1 since we need first index to be 0

while not availability:
    j += 1  # move to next day
    if j == len(Days):
        print('\nChecked all Days There is No availability at all')
        break
    elif Days[j] == 6:
        i = 1
    fillInfo(Months[i], Days[j])
    availability = checkAvailability()

# TODO: Today's Goals
#  1. Store links of available campgrounds into a list
#  2. Access first campground, see if there are 2 available camp sites
#  3. If yes send email with the necessary information
#  4. If not, advance to next link stored in list and repeat steps 2 & 3
